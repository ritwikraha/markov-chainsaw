# OSS model comparison results

Scope: 15 deterministic symbolic model-compatibility probes. These are separate from engine-backed 0 A.D. scores.

| Rank | Model | Correct | Accuracy | Legal actions | Mean latency | Tokens |
|---:|---|---:|---:|---:|---:|---:|
| 1 | `mistralai/Ministral-3-3B-Instruct-2512-BF16` | 15/15 | 100.0% | 100.0% | 1480 ms | 4106 |
| 2 | `google/gemma-4-E2B-it` | 14/15 | 93.3% | 100.0% | 1909 ms | 3941 |
| 3 | `microsoft/Phi-4-mini-instruct` | 9/15 | 60.0% | 66.7% | 1638 ms | 3600 |
| 4 | `Qwen/Qwen3.5-4B` | 5/15 | 33.3% | 53.3% | 2923 ms | 4008 |
